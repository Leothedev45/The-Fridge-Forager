
export enum Difficulty {
  Easy = 'Easy',
  Medium = 'Medium',
  Hard = 'Hard',
}

export enum DietaryRestriction {
  Vegan = 'Vegan',
  Vegetarian = 'Vegetarian',
  GlutenFree = 'Gluten-Free',
  DairyFree = 'Dairy-Free',
  LowCarb = 'Low Carb',
  NutFree = 'Nut-Free',
}

export type View = 'home' | 'search' | 'create' | 'history' | 'settings' | 'recipe-result';

export interface Recipe {
  id: string;
  title: string;
  ingredientsUsed: string;
  content: string; // The markdown content
  image?: string; // Base64 image
  timestamp: number;
  difficulty: Difficulty;
}
