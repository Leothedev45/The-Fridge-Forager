
import React, { useState, useEffect } from 'react';
import { generateRecipe, generateFoodImage } from './services/geminiService';
import { 
  ChefHat, Flame, Leaf, Loader2, Sparkles, AlertCircle, ShoppingBasket, Share2, Check,
  Home as HomeIcon, Search as SearchIcon, History as HistoryIcon, Settings as SettingsIcon, Plus,
  Trash2, ChevronRight, PlusCircle, MinusCircle, LayoutGrid, Type
} from './components/Icons';
import { Difficulty, DietaryRestriction, View, Recipe } from './types';

// Predefined ingredients for the visual builder
const COMMON_INGREDIENTS = [
  { name: 'Eggs', emoji: '🥚', category: 'Dairy & Proteins' },
  { name: 'Milk', emoji: '🥛', category: 'Dairy & Proteins' },
  { name: 'Cheese', emoji: '🧀', category: 'Dairy & Proteins' },
  { name: 'Chicken', emoji: '🍗', category: 'Dairy & Proteins' },
  { name: 'Beef', emoji: '🥩', category: 'Dairy & Proteins' },
  { name: 'Onion', emoji: '🧅', category: 'Produce' },
  { name: 'Tomato', emoji: '🍅', category: 'Produce' },
  { name: 'Potato', emoji: '🥔', category: 'Produce' },
  { name: 'Carrot', emoji: '🥕', category: 'Produce' },
  { name: 'Garlic', emoji: '🧄', category: 'Produce' },
  { name: 'Spinach', emoji: '🍃', category: 'Produce' },
  { name: 'Mushroom', emoji: '🍄', category: 'Produce' },
  { name: 'Rice', emoji: '🍚', category: 'Pantry' },
  { name: 'Pasta', emoji: '🍝', category: 'Pantry' },
  { name: 'Bread', emoji: '🍞', category: 'Pantry' },
  { name: 'Beans', emoji: '🥫', category: 'Pantry' },
];

const App: React.FC = () => {
  // Navigation State
  const [currentView, setCurrentView] = useState<View>('home');
  
  // Data State
  const [history, setHistory] = useState<Recipe[]>([]);
  const [currentRecipe, setCurrentRecipe] = useState<Recipe | null>(null);
  
  // Settings State
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.Medium);
  const [dietary, setDietary] = useState<DietaryRestriction[]>([]);
  
  // Generation State
  const [ingredientsText, setIngredientsText] = useState<string>('');
  const [ingredientsVisual, setIngredientsVisual] = useState<Record<string, number>>({});
  const [inputMode, setInputMode] = useState<'visual' | 'text'>('visual');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  
  // Load data from LocalStorage on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('fridge-forager-history');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
    
    const savedSettings = localStorage.getItem('fridge-forager-settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setDifficulty(parsed.difficulty || Difficulty.Medium);
        setDietary(parsed.dietary || []);
      } catch (e) {}
    }

    // Hash handling for shared recipes
    const hash = window.location.hash;
    if (hash.startsWith('#recipe=')) {
      handleSharedRecipe(hash);
    }
  }, []);

  // Save settings when changed
  useEffect(() => {
    localStorage.setItem('fridge-forager-settings', JSON.stringify({ difficulty, dietary }));
  }, [difficulty, dietary]);

  // Save history when changed
  useEffect(() => {
    localStorage.setItem('fridge-forager-history', JSON.stringify(history));
  }, [history]);

  const handleSharedRecipe = async (hash: string) => {
    try {
      const encoded = hash.replace('#recipe=', '');
      const binaryString = atob(decodeURIComponent(encoded));
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const decodedContent = new TextDecoder().decode(bytes);
      
      // Parse basic details from the shared content
      const titleMatch = decodedContent.match(/^# (.*)$/m);
      const title = titleMatch ? titleMatch[1] : 'Shared Recipe';
      
      const newRecipe: Recipe = {
        id: 'shared-' + Date.now(),
        title,
        ingredientsUsed: 'Shared Link',
        content: decodedContent,
        timestamp: Date.now(),
        difficulty: Difficulty.Medium,
        image: undefined
      };

      setCurrentRecipe(newRecipe);
      setCurrentView('recipe-result');
      window.location.hash = '';

      // Try to generate image for shared recipe
      if (title) {
        generateFoodImage(title).then(img => {
          if (img) {
            setCurrentRecipe(prev => prev ? { ...prev, image: img } : null);
          }
        });
      }
    } catch (err) {
      console.error("Failed to decode recipe", err);
    }
  };

  const toggleDietary = (restriction: DietaryRestriction) => {
    setDietary(prev => 
      prev.includes(restriction) 
        ? prev.filter(r => r !== restriction)
        : [...prev, restriction]
    );
  };

  const updateVisualIngredient = (name: string, delta: number) => {
    setIngredientsVisual(prev => {
      const current = prev[name] || 0;
      const next = Math.max(0, current + delta);
      const newMap = { ...prev, [name]: next };
      if (next === 0) delete newMap[name];
      return newMap;
    });
  };

  const handleGenerate = async () => {
    let finalIngredients = '';
    
    if (inputMode === 'visual') {
      const parts = Object.entries(ingredientsVisual).map(([name, count]) => `${count} ${name}`);
      if (parts.length === 0) {
        setError("Please select at least one ingredient.");
        return;
      }
      finalIngredients = parts.join(', ');
    } else {
      if (!ingredientsText.trim()) {
        setError("Please enter some ingredients.");
        return;
      }
      finalIngredients = ingredientsText;
    }

    setLoading(true);
    setError(null);
    
    try {
      const content = await generateRecipe(finalIngredients, difficulty, dietary);
      
      // Extract title
      const titleMatch = content.match(/^# (.*)$/m);
      const title = titleMatch ? titleMatch[1] : 'New Recipe';

      // Start image generation in background
      let imageUrl: string | undefined = undefined;
      try {
        const img = await generateFoodImage(title);
        if (img) imageUrl = img;
      } catch (e) {
        console.error("Image gen failed", e);
      }

      const newRecipe: Recipe = {
        id: crypto.randomUUID(),
        title,
        ingredientsUsed: finalIngredients,
        content,
        image: imageUrl,
        timestamp: Date.now(),
        difficulty
      };

      setHistory(prev => [newRecipe, ...prev]);
      setCurrentRecipe(newRecipe);
      setCurrentView('recipe-result');
      
      // Reset inputs
      setIngredientsText('');
      setIngredientsVisual({});
      
    } catch (err) {
      console.error(err);
      setError("Failed to generate recipe. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const deleteRecipe = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHistory(prev => prev.filter(r => r.id !== id));
    if (currentRecipe?.id === id) {
      setCurrentRecipe(null);
      setCurrentView('history');
    }
  };

  const handleShare = async () => {
    if (!currentRecipe) return;
    try {
      const bytes = new TextEncoder().encode(currentRecipe.content);
      let binary = '';
      for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      const base64 = btoa(binary);
      const shareUrl = `${window.location.origin}${window.location.pathname}#recipe=${encodeURIComponent(base64)}`;
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return (
          <div className="space-y-8 animate-fade-in">
            <header className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-serif font-bold text-stone-900">Welcome Back</h1>
                <p className="text-stone-500">Ready to forage something delicious?</p>
              </div>
              <ChefHat className="w-10 h-10 text-emerald-600 opacity-20" />
            </header>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-100 flex flex-col items-center justify-center text-center">
                <span className="text-4xl font-bold text-emerald-600 mb-1">{history.length}</span>
                <span className="text-sm text-stone-500 font-medium">Recipes Created</span>
              </div>
               <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-100 flex flex-col items-center justify-center text-center">
                <span className="text-4xl font-bold text-orange-500 mb-1">{difficulty}</span>
                <span className="text-sm text-stone-500 font-medium">Current Level</span>
              </div>
            </div>

            {history.length > 0 ? (
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-stone-100 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full -mr-16 -mt-16 z-0" />
                <div className="relative z-10">
                  <h3 className="font-serif font-bold text-xl text-stone-900 mb-2">Last Cooked</h3>
                  <div className="flex items-center gap-4 mb-4">
                    {history[0].image ? (
                      <img src={history[0].image} className="w-16 h-16 rounded-lg object-cover bg-stone-200" alt="Thumbnail" />
                    ) : (
                      <div className="w-16 h-16 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600">
                        <ChefHat className="w-8 h-8" />
                      </div>
                    )}
                    <div>
                      <h4 className="font-bold text-stone-800 line-clamp-1">{history[0].title}</h4>
                      <p className="text-xs text-stone-500">{new Date(history[0].timestamp).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => { setCurrentRecipe(history[0]); setCurrentView('recipe-result'); }}
                    className="w-full py-3 bg-stone-100 text-stone-700 font-semibold rounded-xl hover:bg-stone-200 transition-colors"
                  >
                    View Recipe
                  </button>
                </div>
              </div>
            ) : (
               <div className="bg-emerald-50 rounded-2xl p-8 text-center border border-emerald-100">
                  <Sparkles className="w-10 h-10 text-emerald-500 mx-auto mb-3" />
                  <h3 className="font-serif font-bold text-xl text-emerald-900 mb-2">Start Your Journey</h3>
                  <p className="text-emerald-700/80 mb-6 text-sm">Create your first AI-powered recipe today.</p>
                  <button onClick={() => setCurrentView('create')} className="px-6 py-2 bg-emerald-600 text-white rounded-lg font-medium shadow-md">Create Now</button>
               </div>
            )}
            
            <div className="pt-4">
              <button 
                onClick={() => setCurrentView('create')}
                className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white font-bold rounded-2xl shadow-lg shadow-emerald-200 flex items-center justify-center gap-2 transform active:scale-95 transition-all"
              >
                <Plus className="w-6 h-6" />
                New Creation
              </button>
            </div>
          </div>
        );

      case 'search':
        return <SearchView history={history} onView={(r) => { setCurrentRecipe(r); setCurrentView('recipe-result'); }} />;

      case 'history':
        return (
          <div className="space-y-6 animate-fade-in pb-20">
            <h1 className="text-3xl font-serif font-bold text-stone-900">Your Cookbook</h1>
            {history.length === 0 ? (
               <div className="text-center py-20 text-stone-400">
                 <HistoryIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
                 <p>No recipes yet.</p>
               </div>
            ) : (
              <div className="space-y-4">
                {history.map(r => (
                  <div key={r.id} onClick={() => { setCurrentRecipe(r); setCurrentView('recipe-result'); }} className="bg-white p-4 rounded-xl shadow-sm border border-stone-100 flex items-center gap-4 cursor-pointer hover:shadow-md transition-all active:scale-[0.99]">
                    {r.image ? (
                      <img src={r.image} className="w-16 h-16 rounded-lg object-cover bg-stone-200" alt="Thumbnail" />
                    ) : (
                      <div className="w-16 h-16 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                        <ChefHat className="w-8 h-8" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-stone-800 line-clamp-1">{r.title}</h4>
                      <p className="text-xs text-stone-500 line-clamp-1">{r.ingredientsUsed}</p>
                      <span className="text-[10px] text-stone-400 mt-1 block">{new Date(r.timestamp).toLocaleDateString()}</span>
                    </div>
                    <button onClick={(e) => deleteRecipe(r.id, e)} className="p-2 text-stone-300 hover:text-red-500 transition-colors">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
             <div className="pt-4 flex justify-center">
               <button onClick={() => setCurrentView('create')} className="text-emerald-600 font-medium text-sm flex items-center gap-1">
                 Create another <ChevronRight className="w-4 h-4" />
               </button>
             </div>
          </div>
        );

      case 'settings':
        return (
           <div className="space-y-8 animate-fade-in pb-20">
             <h1 className="text-3xl font-serif font-bold text-stone-900">Kitchen Settings</h1>
             
             <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
               <div className="p-4 bg-stone-50 border-b border-stone-200 font-bold text-stone-700 flex items-center gap-2">
                 <Flame className="w-4 h-4" /> Cooking Skill
               </div>
               <div className="p-4 grid grid-cols-1 gap-2">
                  {Object.values(Difficulty).map((level) => (
                    <button
                      key={level}
                      onClick={() => setDifficulty(level)}
                      className={`flex items-center justify-between p-3 rounded-lg border transition-all ${
                        difficulty === level
                          ? 'bg-emerald-50 border-emerald-500 text-emerald-800 font-medium'
                          : 'bg-white border-stone-100 text-stone-600 hover:bg-stone-50'
                      }`}
                    >
                      {level}
                      {difficulty === level && <Check className="w-4 h-4" />}
                    </button>
                  ))}
               </div>
             </div>

             <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
               <div className="p-4 bg-stone-50 border-b border-stone-200 font-bold text-stone-700 flex items-center gap-2">
                 <Leaf className="w-4 h-4" /> Dietary Preferences
               </div>
               <div className="p-4 space-y-2">
                  {Object.values(DietaryRestriction).map((restriction) => (
                    <label
                      key={restriction}
                      className={`flex items-center p-3 rounded-lg border cursor-pointer transition-all ${
                        dietary.includes(restriction)
                          ? 'bg-emerald-50 border-emerald-400'
                          : 'bg-white border-stone-100 hover:border-stone-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 border-gray-300"
                        checked={dietary.includes(restriction)}
                        onChange={() => toggleDietary(restriction)}
                      />
                      <span className={`ml-3 text-sm ${dietary.includes(restriction) ? 'text-emerald-900 font-medium' : 'text-stone-600'}`}>
                        {restriction}
                      </span>
                    </label>
                  ))}
               </div>
             </div>
             
             <div className="text-center pt-8">
                 <button onClick={() => setCurrentView('create')} className="bg-emerald-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-emerald-700 transition-all">
                    Go to Kitchen
                 </button>
             </div>
           </div>
        );

      case 'create':
        return (
          <div className="animate-fade-in pb-20">
             <div className="text-center mb-6">
                <h1 className="text-3xl font-serif font-bold text-stone-900 mb-2">What's in the fridge?</h1>
                <p className="text-stone-500 text-sm">Add ingredients to start cooking.</p>
             </div>

             {/* Mode Toggle */}
             <div className="flex bg-stone-200 p-1 rounded-xl mb-6 max-w-xs mx-auto">
               <button 
                 onClick={() => setInputMode('visual')}
                 className={`flex-1 py-2 text-sm font-medium rounded-lg flex items-center justify-center gap-2 transition-all ${inputMode === 'visual' ? 'bg-white text-emerald-800 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}
               >
                 <LayoutGrid className="w-4 h-4" /> Visual
               </button>
               <button 
                 onClick={() => setInputMode('text')}
                 className={`flex-1 py-2 text-sm font-medium rounded-lg flex items-center justify-center gap-2 transition-all ${inputMode === 'text' ? 'bg-white text-emerald-800 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}
               >
                 <Type className="w-4 h-4" /> Advanced
               </button>
             </div>

             {inputMode === 'visual' ? (
               <div className="space-y-6">
                  {/* Selected Summary */}
                  {Object.keys(ingredientsVisual).length > 0 && (
                     <div className="bg-white p-4 rounded-xl border border-emerald-100 shadow-sm sticky top-0 z-10 backdrop-blur-md bg-white/90">
                       <h3 className="text-xs font-bold text-emerald-800 uppercase tracking-wider mb-2">Selected</h3>
                       <div className="flex flex-wrap gap-2">
                          {Object.entries(ingredientsVisual).map(([name, count]) => (
                             <span key={name} className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-900 px-3 py-1 rounded-full text-sm font-medium">
                               {count} {name}
                               <button onClick={() => updateVisualIngredient(name, -1)} className="hover:text-red-500"><Trash2 className="w-3 h-3" /></button>
                             </span>
                          ))}
                       </div>
                     </div>
                  )}

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                     {COMMON_INGREDIENTS.map((item) => {
                       const count = ingredientsVisual[item.name] || 0;
                       return (
                         <div key={item.name} onClick={() => updateVisualIngredient(item.name, 1)} className={`bg-white p-4 rounded-xl border cursor-pointer transition-all active:scale-95 select-none ${count > 0 ? 'border-emerald-500 ring-1 ring-emerald-500 bg-emerald-50' : 'border-stone-200 hover:border-emerald-300'}`}>
                           <div className="text-3xl mb-2">{item.emoji}</div>
                           <div className="flex items-center justify-between">
                             <span className="font-medium text-stone-800 text-sm">{item.name}</span>
                             {count > 0 ? (
                               <div className="flex items-center gap-2 bg-white rounded-full px-1 shadow-sm border border-stone-200" onClick={(e) => e.stopPropagation()}>
                                 <button onClick={() => updateVisualIngredient(item.name, -1)} className="p-1 text-stone-400 hover:text-emerald-600"><MinusCircle className="w-4 h-4" /></button>
                                 <span className="text-xs font-bold w-3 text-center">{count}</span>
                                 <button onClick={() => updateVisualIngredient(item.name, 1)} className="p-1 text-stone-400 hover:text-emerald-600"><PlusCircle className="w-4 h-4" /></button>
                               </div>
                             ) : (
                               <PlusCircle className="w-5 h-5 text-stone-300" />
                             )}
                           </div>
                         </div>
                       );
                     })}
                  </div>
               </div>
             ) : (
               <div className="bg-transparent p-1 rounded-xl">
                 <textarea
                   value={ingredientsText}
                   onChange={(e) => setIngredientsText(e.target.value)}
                   placeholder="e.g., 2 eggs, half an onion, some cheddar cheese..."
                   className="w-full h-64 p-4 rounded-lg border border-stone-300 bg-transparent focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all resize-none text-stone-900 text-lg placeholder:text-stone-500"
                 />
               </div>
             )}

             <div className="mt-8">
                {error && (
                  <div className="mb-4 p-4 bg-red-50 text-red-700 rounded-lg flex items-center gap-3 animate-fade-in border border-red-100">
                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                    <p>{error}</p>
                  </div>
                )}

                <button
                  onClick={handleGenerate}
                  disabled={loading}
                  className={`w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-bold text-white shadow-lg transition-all transform active:scale-95 ${
                    loading
                      ? 'bg-stone-300 cursor-not-allowed shadow-none'
                      : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:shadow-emerald-200'
                  }`}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Chef is thinking...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      Generate Recipe
                    </>
                  )}
                </button>
             </div>
          </div>
        );

      case 'recipe-result':
        if (!currentRecipe) return null;
        const { mainContent, nutritionRaw } = parseRecipeContent(currentRecipe.content);
        return (
           <div className="animate-slide-up pb-20">
              <div className="bg-white rounded-xl shadow-sm border border-stone-100 overflow-hidden">
                <div className="relative h-64 md:h-80 bg-stone-100 w-full">
                  {currentRecipe.image ? (
                    <img src={currentRecipe.image} alt="Dish" className="w-full h-full object-cover" />
                  ) : (
                     <div className="w-full h-full bg-gradient-to-br from-emerald-800 to-teal-900 flex items-center justify-center">
                        <ChefHat className="w-20 h-20 text-white/20" />
                     </div>
                  )}
                  <div className="absolute top-4 right-4">
                    <button onClick={handleShare} className={`flex items-center gap-2 px-3 py-2 rounded-full shadow-lg backdrop-blur-md text-sm font-bold transition-all ${copied ? 'bg-emerald-500 text-white' : 'bg-white/90 text-stone-800 hover:bg-white'}`}>
                        {copied ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
                        {copied ? 'Copied!' : 'Share'}
                    </button>
                  </div>
                </div>
                
                <div className="p-6 md:p-10">
                   <RecipeRenderer content={mainContent} />
                   {nutritionRaw && (
                      <div className="mt-12">
                          <div className="border-2 border-stone-800 rounded-sm p-6 bg-white max-w-md mx-auto shadow-[4px_4px_0px_0px_rgba(40,40,40,0.1)]">
                              <h3 className="text-2xl font-black text-stone-900 border-b-4 border-stone-900 pb-1 mb-4 uppercase tracking-wide">Nutrition Facts</h3>
                              <div className="space-y-3">
                                  {nutritionRaw.split('\n').filter(line => line.trim().startsWith('-') || line.trim().startsWith('*')).map((line, idx) => {
                                      const clean = line.replace(/^[-*]\s*/, '').trim();
                                      const parts = clean.split(':');
                                      if (parts.length < 2) return null;
                                      return (
                                          <div key={idx} className="flex justify-between items-end border-b border-stone-300 pb-1 last:border-0">
                                              <span className="font-bold text-stone-700">{parts[0]}</span>
                                              <span className="font-medium text-stone-900">{parts[1]}</span>
                                          </div>
                                      );
                                  })}
                              </div>
                          </div>
                      </div>
                   )}
                </div>
                <div className="p-6 bg-stone-50 border-t border-stone-100 text-center">
                   <button onClick={() => setCurrentView('create')} className="text-emerald-600 font-bold flex items-center justify-center gap-2 mx-auto hover:underline">
                      Cook Something Else <ChevronRight className="w-4 h-4" />
                   </button>
                </div>
              </div>
           </div>
        );
        
      default: return null;
    }
  };

  // Helper to parse existing Markdown
  const parseRecipeContent = (content: string) => {
    const nutritionRegex = /(?:^|\n)##\s*Nutrition.*(?:\n|$)([\s\S]*)/i;
    const match = content.match(nutritionRegex);
    if (match) {
      const nutritionRaw = match[1].trim();
      const mainContent = content.replace(match[0], '').trim();
      return { mainContent, nutritionRaw };
    }
    return { mainContent: content, nutritionRaw: null };
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-800 font-sans flex justify-center">
      <div className="w-full max-w-2xl min-h-screen bg-stone-50 flex flex-col relative shadow-2xl shadow-stone-200/50">
        
        {/* Main Content Area */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto">
          {renderView()}
        </main>

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-stone-100 h-20 flex items-center justify-around z-50 md:max-w-2xl md:mx-auto md:rounded-t-2xl md:shadow-[0_-5px_20px_rgba(0,0,0,0.03)]">
          <NavButton icon={<HomeIcon className="w-6 h-6" />} label="Home" active={currentView === 'home'} onClick={() => setCurrentView('home')} />
          <NavButton icon={<SearchIcon className="w-6 h-6" />} label="Search" active={currentView === 'search'} onClick={() => setCurrentView('search')} />
          
          <div className="relative -top-6">
            <button 
              onClick={() => setCurrentView('create')}
              className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-700 rounded-full flex items-center justify-center text-white shadow-xl shadow-emerald-200/50 transform transition-transform active:scale-95 border-4 border-stone-50"
            >
              <Plus className="w-8 h-8" />
            </button>
          </div>

          <NavButton icon={<HistoryIcon className="w-6 h-6" />} label="History" active={currentView === 'history'} onClick={() => setCurrentView('history')} />
          <NavButton icon={<SettingsIcon className="w-6 h-6" />} label="Settings" active={currentView === 'settings'} onClick={() => setCurrentView('settings')} />
        </nav>

      </div>
    </div>
  );
};

// Subcomponents

const NavButton: React.FC<{ icon: React.ReactNode, label: string, active: boolean, onClick: () => void }> = ({ icon, label, active, onClick }) => (
  <button onClick={onClick} className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-emerald-600' : 'text-stone-400 hover:text-stone-600'}`}>
    {icon}
    <span className="text-[10px] font-medium">{label}</span>
  </button>
);

const SearchView: React.FC<{ history: Recipe[], onView: (r: Recipe) => void }> = ({ history, onView }) => {
  const [query, setQuery] = useState('');
  const filtered = history.filter(h => 
    h.title.toLowerCase().includes(query.toLowerCase()) || 
    h.ingredientsUsed.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in pb-20">
       <div className="relative">
         <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5" />
         <input 
           type="text" 
           placeholder="Search your recipes..." 
           value={query}
           onChange={(e) => setQuery(e.target.value)}
           className="w-full pl-12 pr-4 py-4 rounded-xl border border-stone-200 bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all outline-none"
         />
       </div>

       <div className="space-y-4">
          {filtered.length === 0 ? (
             <p className="text-center text-stone-400 mt-10">No recipes found matching "{query}".</p>
          ) : (
            filtered.map(r => (
              <div key={r.id} onClick={() => onView(r)} className="bg-white p-4 rounded-xl shadow-sm border border-stone-100 flex gap-4 cursor-pointer hover:bg-stone-50 transition-colors">
                 {r.image ? (
                   <img src={r.image} className="w-20 h-20 rounded-lg object-cover bg-stone-200" alt="Thumbnail" />
                 ) : (
                   <div className="w-20 h-20 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                     <ChefHat className="w-8 h-8" />
                   </div>
                 )}
                 <div>
                    <h3 className="font-bold text-stone-900 line-clamp-1">{r.title}</h3>
                    <p className="text-xs text-stone-500 line-clamp-2 mt-1">{r.ingredientsUsed}</p>
                 </div>
              </div>
            ))
          )}
       </div>
    </div>
  );
};

const RecipeRenderer: React.FC<{ content: string }> = ({ content }) => {
  const lines = content.split('\n');
  return (
    <div className="space-y-4 text-stone-700 leading-relaxed">
      {lines.map((line, index) => {
        if (line.startsWith('### ')) return <h3 key={index} className="text-xl font-bold text-emerald-800 mt-6 mb-3 font-serif border-b border-emerald-100 pb-1">{line.replace('### ', '')}</h3>;
        if (line.startsWith('## ')) return <h2 key={index} className="text-2xl font-bold text-emerald-900 mt-8 mb-4 border-b border-stone-200 pb-2 font-serif">{line.replace('## ', '')}</h2>;
        if (line.startsWith('# ')) return <h1 key={index} className="text-3xl md:text-4xl font-bold text-emerald-950 mb-6 font-serif">{line.replace('# ', '')}</h1>;
        if (line.trim().startsWith('- ')) return <div key={index} className="flex items-start gap-2 ml-1"><span className="text-emerald-500 mt-1.5">•</span><span className="flex-1">{line.trim().substring(2)}</span></div>;
        if (/^\d+\./.test(line.trim())) {
             const [num, ...rest] = line.trim().split('.');
             return <div key={index} className="flex items-start gap-3 ml-1 mb-3"><span className="flex-shrink-0 w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center mt-0.5">{num}</span><span className="flex-1">{rest.join('.')}</span></div>;
        }
        const parts = line.split('**');
        if (line.trim() === '') return <div key={index} className="h-2"></div>;
        return <p key={index} className="mb-2">{parts.map((part, i) => i % 2 === 1 ? <strong key={i} className="font-semibold text-stone-900">{part}</strong> : part)}</p>;
      })}
    </div>
  );
};

export default App;
