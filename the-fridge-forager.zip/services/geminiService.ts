import { GoogleGenAI } from "@google/genai";
import { Difficulty, DietaryRestriction } from "../types";

// Initialize Gemini Client
// Note: API Key is sourced from environment variables as per strict system instructions.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateRecipe = async (
  ingredients: string,
  difficulty: Difficulty,
  dietaryRestrictions: DietaryRestriction[]
): Promise<string> => {
  try {
    const model = "gemini-2.5-flash"; // Using flash for speed and efficiency on text tasks
    
    // Constructing a detailed prompt to ensure the AI behaves like a chef
    const dietaryString = dietaryRestrictions.length > 0 
        ? `Dietary Restrictions: ${dietaryRestrictions.join(', ')} (STRICTLY ADHERE TO THESE)` 
        : 'Dietary Restrictions: None';

    const prompt = `
      You are a world-class, creative executive chef known for reducing food waste by creating gourmet meals from limited ingredients.

      TASK:
      Create a coherent, delicious recipe using ONLY the user's provided ingredients below, plus allowed pantry staples.
      
      USER INGREDIENTS:
      ${ingredients}

      ALLOWED PANTRY STAPLES (You may assume the user has these):
      - Water
      - Oil (Olive, Vegetable, etc.)
      - Salt
      - Pepper
      - Sugar/Honey (in small amounts)
      - Flour (basic)
      - Vinegar/Lemon juice
      
      CONSTRAINTS:
      1. Difficulty Level: ${difficulty}
      2. ${dietaryString}
      3. Do NOT invent main ingredients not listed above. If the user lists "eggs and cheese", do not add "chicken".
      4. Be creative with techniques to make it special.

      OUTPUT FORMAT (Markdown):
      - Title (Catchy and descriptive, start with #)
      - Brief description (1-2 sentences making it sound appetizing)
      - Prep Time & Cook Time
      - Ingredients List (Quantities can be estimated based on typical logic, e.g., "2 eggs" -> "2 eggs")
      - Step-by-Step Instructions (Clear, numbered steps)
      - Chef's Tip (A small piece of advice for this specific dish)
      - ## Nutrition Information
        - Calories: [Value]
        - Protein: [Value]
        - Carbohydrates: [Value]
        - Fat: [Value]
        (Ensure this section starts exactly with "## Nutrition Information" and uses a bulleted list for the items)
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: "You are a helpful, creative, and safety-conscious AI chef.",
        temperature: 0.4, // A bit of creativity
      }
    });

    if (!response.text) {
      throw new Error("No response received from the model.");
    }

    return response.text;

  } catch (error) {
    console.error("Error generating recipe:", error);
    throw error;
  }
};

export const generateFoodImage = async (recipeTitle: string): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: `A professional, high-quality, gourmet food photography shot of a dish called "${recipeTitle}". Photorealistic, studio lighting, appetizing, 4k resolution.` },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
        }
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    // Return null so the UI can gracefully show just text if image fails
    return null;
  }
};